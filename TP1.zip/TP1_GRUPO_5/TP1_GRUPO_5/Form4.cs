﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1_GRUPO_5
{
    public partial class frmEjercicio3 : Form
    {
        public frmEjercicio3()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            List<string> resultado = new List<string>();

            resultado.Add("Usted selecciono los siguientes items: ");
            if (rbFemenino.Checked)
            {
                resultado.Add("Sexo: Femenino");
            }
            else { if (rbMasculino.Checked) { resultado.Add("Sexo: Masculino "); } }

            if (rbCasado.Checked) { resultado.Add("Estado civil: Casado "); }
            else { if (rbSoltero.Checked) { resultado.Add("Estado civil: Soltero"); } }
            resultado.Add("Oficio: ");
            for (int i = 0; i <= (ckListBox.Items.Count - 1); i++)
            {
                if (ckListBox.GetItemChecked(i))
                {
                    resultado.Add(ckListBox.Items[i].ToString());
                }
            }
            label1.Text = string.Join("\n ", resultado.ToArray());


        }
    }
}
