﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1_GRUPO_5
{
    public partial class frmEjercicio2 : Form
    {
        public frmEjercicio2()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)

        {
            bool NoRepite = true; //Variable para verificar no se repite el nombre completo

            string n1 = txtNombre.Text.Trim();
            string a1 = txtApellido.Text.Trim();//"Trim() sirve para eliminar los espacios en blanco"
            errorProvider1.SetError(txtNombre, "");
            errorProvider1.SetError(txtApellido, "");
            errorProvider1.SetError(btnAgregar, "");
            if (n1 != "")
            {
                if (a1 != "")
                {

                    foreach (string nombreCompleto in lstElementos.Items) //Esta funcion recorre item por item dentro de la lista de elementos
                    {
                        if (nombreCompleto.ToUpper() == n1.ToUpper() + " " + a1.ToUpper()) //Este If compara cada item existente contra el nombre que queremos agregar
                        {
                            NoRepite = false;  //Si es el nombre que queremos agregar ya existe, la variable NoRepite cambiara a false
                        }
                    }
                    if (NoRepite)
                    {
                        lstElementos.Items.Add(n1 + " " + a1);
                    }
                    else
                    {
                        errorProvider1.SetError(btnAgregar, "EL NOMBRE Y APELLIDO YA EXISTEN EN LA LISTA");
                    }
                    txtApellido.Text = "";
                    txtNombre.Text = "";
                }

                else {  errorProvider1.SetError(txtApellido, "INGRESAR APELLIDO");  }

            }
            else {
                errorProvider1.SetError(txtNombre, "INGRESAR NOMBRE");
            }
        }
    
      
       
        private void btnBorrar_Click(object sender, EventArgs e)
        {
           if(lstElementos.SelectedIndex != -1)
            {
                lstElementos.Items.RemoveAt(lstElementos.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Seleccione un elemento de la lista", "ATENCION");
            }
        }
    }
}
