﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1_GRUPO_5
{
    public partial class frmEjercicio1 : Form
    {
        public frmEjercicio1()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            bool comparacion = false;

            if (txtNombre.Text.Trim() != "")
            {
                foreach (string Nombre in lbIzquierda.Items)
                {
                    if (txtNombre.Text.ToUpper().Trim() == Nombre.ToUpper().Trim())
                    {
                        comparacion = true;
                    }
                }
                if (comparacion) {
                    MessageBox.Show("El nombre ingresado ya se encuentra en la lista","ATENCION");
                }
                else
                {
                    lbIzquierda.Items.Add(txtNombre.Text.Trim());
                }

                txtNombre.Text = "";
            }
           
        }

        private void btnPasarUno_Click(object sender, EventArgs e)
        {
            
            
            if (lbIzquierda.SelectedIndex ==-1)
            {
                MessageBox.Show("Seleccione algun elemento de la lista", "ATENCION");
            }
            else
            {
                
                    lbDerecha.Items.Add(lbIzquierda.SelectedItem);
                    int aux2 = lbIzquierda.SelectedIndex;
                    lbIzquierda.Items.RemoveAt(aux2);
          
            }
            
        }

        private void btnPasarTodo_Click(object sender, EventArgs e)
        {
            lbDerecha.Items.AddRange(lbIzquierda.Items);
            lbIzquierda.Items.Clear();

        }
    }
}
