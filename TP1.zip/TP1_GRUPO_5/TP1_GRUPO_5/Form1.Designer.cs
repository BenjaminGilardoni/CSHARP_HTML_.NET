﻿
namespace TP1_GRUPO_5
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEjercicio1 = new System.Windows.Forms.Button();
            this.btnEjercicio2 = new System.Windows.Forms.Button();
            this.btnEjercicio3 = new System.Windows.Forms.Button();
            this.lblIntegrantes = new System.Windows.Forms.Label();
            this.lblNahir = new System.Windows.Forms.Label();
            this.lblBenjamin = new System.Windows.Forms.Label();
            this.lblSantiago = new System.Windows.Forms.Label();
            this.lblGaston = new System.Windows.Forms.Label();
            this.lblAna = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEjercicio1
            // 
            this.btnEjercicio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEjercicio1.Location = new System.Drawing.Point(169, 38);
            this.btnEjercicio1.Name = "btnEjercicio1";
            this.btnEjercicio1.Size = new System.Drawing.Size(107, 49);
            this.btnEjercicio1.TabIndex = 0;
            this.btnEjercicio1.Text = "Ejercicio 1";
            this.btnEjercicio1.UseVisualStyleBackColor = true;
            this.btnEjercicio1.Click += new System.EventHandler(this.btnEjercicio1_Click);
            // 
            // btnEjercicio2
            // 
            this.btnEjercicio2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEjercicio2.Location = new System.Drawing.Point(341, 38);
            this.btnEjercicio2.Name = "btnEjercicio2";
            this.btnEjercicio2.Size = new System.Drawing.Size(97, 49);
            this.btnEjercicio2.TabIndex = 1;
            this.btnEjercicio2.Text = "Ejercicio 2";
            this.btnEjercicio2.UseVisualStyleBackColor = true;
            this.btnEjercicio2.Click += new System.EventHandler(this.btnEjercicio2_Click);
            // 
            // btnEjercicio3
            // 
            this.btnEjercicio3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEjercicio3.Location = new System.Drawing.Point(496, 38);
            this.btnEjercicio3.Name = "btnEjercicio3";
            this.btnEjercicio3.Size = new System.Drawing.Size(99, 49);
            this.btnEjercicio3.TabIndex = 2;
            this.btnEjercicio3.Text = "Ejercicio 3";
            this.btnEjercicio3.UseVisualStyleBackColor = true;
            this.btnEjercicio3.Click += new System.EventHandler(this.btnEjercicio3_Click);
            // 
            // lblIntegrantes
            // 
            this.lblIntegrantes.AutoSize = true;
            this.lblIntegrantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIntegrantes.Location = new System.Drawing.Point(89, 147);
            this.lblIntegrantes.Name = "lblIntegrantes";
            this.lblIntegrantes.Size = new System.Drawing.Size(107, 20);
            this.lblIntegrantes.TabIndex = 3;
            this.lblIntegrantes.Text = "Integrantes:";
            // 
            // lblNahir
            // 
            this.lblNahir.AutoSize = true;
            this.lblNahir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNahir.Location = new System.Drawing.Point(195, 171);
            this.lblNahir.Name = "lblNahir";
            this.lblNahir.Size = new System.Drawing.Size(139, 16);
            this.lblNahir.TabIndex = 4;
            this.lblNahir.Text = "Nahir Fernanda Rosul";
            this.lblNahir.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBenjamin
            // 
            this.lblBenjamin.AutoSize = true;
            this.lblBenjamin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBenjamin.Location = new System.Drawing.Point(195, 192);
            this.lblBenjamin.Name = "lblBenjamin";
            this.lblBenjamin.Size = new System.Drawing.Size(121, 16);
            this.lblBenjamin.TabIndex = 5;
            this.lblBenjamin.Text = "Benjamín Gilardoni";
            // 
            // lblSantiago
            // 
            this.lblSantiago.AutoSize = true;
            this.lblSantiago.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSantiago.Location = new System.Drawing.Point(195, 214);
            this.lblSantiago.Name = "lblSantiago";
            this.lblSantiago.Size = new System.Drawing.Size(103, 16);
            this.lblSantiago.TabIndex = 6;
            this.lblSantiago.Text = "Santiago Brunet";
            // 
            // lblGaston
            // 
            this.lblGaston.AutoSize = true;
            this.lblGaston.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGaston.Location = new System.Drawing.Point(195, 236);
            this.lblGaston.Name = "lblGaston";
            this.lblGaston.Size = new System.Drawing.Size(203, 16);
            this.lblGaston.TabIndex = 7;
            this.lblGaston.Text = "Gastón Esteban Yamevo Blanco";
            // 
            // lblAna
            // 
            this.lblAna.AutoSize = true;
            this.lblAna.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAna.Location = new System.Drawing.Point(195, 260);
            this.lblAna.Name = "lblAna";
            this.lblAna.Size = new System.Drawing.Size(169, 16);
            this.lblAna.TabIndex = 8;
            this.lblAna.Text = "Ana Barbara Aranda Perez";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAna);
            this.Controls.Add(this.lblGaston);
            this.Controls.Add(this.lblSantiago);
            this.Controls.Add(this.lblBenjamin);
            this.Controls.Add(this.lblNahir);
            this.Controls.Add(this.lblIntegrantes);
            this.Controls.Add(this.btnEjercicio3);
            this.Controls.Add(this.btnEjercicio2);
            this.Controls.Add(this.btnEjercicio1);
            this.Name = "frmPrincipal";
            this.Text = "Formulario principal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEjercicio1;
        private System.Windows.Forms.Button btnEjercicio2;
        private System.Windows.Forms.Button btnEjercicio3;
        private System.Windows.Forms.Label lblIntegrantes;
        private System.Windows.Forms.Label lblNahir;
        private System.Windows.Forms.Label lblBenjamin;
        private System.Windows.Forms.Label lblSantiago;
        private System.Windows.Forms.Label lblGaston;
        private System.Windows.Forms.Label lblAna;
    }
}

